[![CircleCI](https://circleci.com/gh/tarex/reusecore.svg?style=svg&circle-token=bfdf44ac1fd845045c98571946c49eb443868962)](https://circleci.com/gh/tarex/reusecore)

### Reuse Core

## For Development On this Repo Run:

Add Below Line at your package.json file:

```
"script" : {
"install": "install-peers"
}

```

Then Run:

```
yarn or yarn install
```
