const data = {
  features: [
    {
      id: 1,
      icon: 'flaticon-atom',
      title: 'App Development',
      description:
        'If you have to develop a mobile app, this is the most appropriate time. ',
    },
    {
      id: 2,
      icon: 'flaticon-trophy',
      title: 'UI/UX Design',
      description:
        'We provide the best UI/UX Design by following the latest trends of the market.',
    },
    {
      id: 3,
      icon: 'flaticon-conversation',
      title: 'Wireframing Task',
      description: ' We respect our customer opinions and deals with them. ',
    },
  ],
};
export default data;
