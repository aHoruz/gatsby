After downloading the file from themeforest, You will find SuperProps.zip file.Then unzip the SuperProps.zip and run the following commands ,
**If you want to run these template on Next Js server , then**

1. 'yarn' on SuperProps folder.
2. 'yarn web' SuperProps folder.
   Then , please go to address localhost:3000 on your browser and You will find agency landing page.
   Similarly ,
   **If you want to Build these template on Next Js server , then**
3. 'yarn' on SuperProps folder.
4. 'yarn landing-build' on SuperProps folder.
   3.'yarn landing-start' on SuperProps folder.

**If you want to run these template on Gatsby Js server , then**

1. 'yarn' on SuperProps folder.
2. 'yarn gatsby-dev' SuperProps folder.
   Then , please go to address localhost:8000 on your browser and You will find agency landing page.
   Similarly ,
   **If you want to Build these template on Gatsby Js server , then**
3. 'yarn' on SuperProps folder.
4. 'yarn gatsby-build' on SuperProps folder.
   3.'yarn gatsby-serve' on SuperProps folder.
